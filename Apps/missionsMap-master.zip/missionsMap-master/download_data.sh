#!/bin/sh
R --no-save < download_data.R > download_data.out
